from __future__ import division
import numpy as np
import scipy.cluster as sp
import sklearn.cluster as sk
import matplotlib.pyplot as plt
import plotQ1
import EM
from scipy.stats import multivariate_normal


def readDate(filename):
	num_lines=sum(1 for line in open('E:\Arjun\work\programs\python\code\pr\\assignment3\data\\'+filename+'.txt'))
	data=np.zeros((num_lines,2))
	
	count=0
	with open("E:\Arjun\work\programs\python\code\pr\\assignment3\data\\"+filename+'.txt','r') as fo:
		for line in fo:
			lis=np.asarray(line.split())
			lis=lis.astype('float64')
			data[count,0]=lis[0]
			data[count,1]=lis[1]
			count=count+1
	plt.plot(data[:,0],data[:,1],'o')
	data1=data[0:1800]
	validationData=data[1400:1800]
	testData=data[1800:2000]
	#plt.show()
	return data1,validationData,testData

def runKMeans(data,k):
	features=sk.KMeans(n_clusters=k,n_init=20,max_iter=400).fit(data)
	#print(features.labels_)
	plt=plotQ1.plotKMeans(data,features,k)
	return features,plt

def calculateVariance(data,labels,k):
	covariance=np.zeros((k,2,2))
	diagconvariance=np.zeros((k,2,2))
	clusterDictionary=dict()
	for i in range(k):
		label=[j for j,x in enumerate(labels) if x==i]

		datum=[data[j,:] for j in label]
		datum=np.array(datum)
		clusterDictionary[i]=datum
		covariance[i]=np.cov(datum[:,0],datum[:,1])
		for j in range(2):
			for k in range(2):
				if(k==j):
					diagconvariance[i,j,k]=covariance[i,j,k]
	#print("asdasdasdas",diagconvariance[0])	
	return covariance,clusterDictionary

def calculateProbability(data,mean,covariance):
	
	u=data-mean
	det=np.sqrt(np.linalg.det(covariance))
	sqrtpi2=2*np.pi	
	inv=np.linalg.inv(covariance)
	a=np.multiply(np.transpose(u),inv)	
	prob=np.exp(-0.5*np.sum(np.multiply(np.multiply(np.transpose(u),inv),u)))
	
	
	prob=prob/(sqrtpi2*det)
	var = multivariate_normal(mean=mean, cov=covariance)
	prob=var.pdf(data)
	return prob

def createGaussianMixture(data,features,k,N):
	mean=np.array((k,2))
	mean=features.cluster_centers_
	print("kmean=",mean)
	
	piK=np.zeros((k,1))
	label=features.labels_
	covariance,clusterDictionary=calculateVariance(data,features.labels_,k)
	print("kmencov=",covariance)

	for K in range(k):
		piK[K,0]=len(clusterDictionary[K])/data.shape[0]
	#print("pikme=",piK)
	mean,covariance,likelihood=EM.runUpdate(data,clusterDictionary,mean,covariance,k,piK,N)
	return mean,covariance,likelihood,piK

def calculateResponsibility(data,mean,covariance,piK,K):
	responsibility=np.zeros((data.shape[0],K))
	den1=np.zeros(data.shape[0])

	for n in range(data.shape[0]):
		den=0
		for k in range(K):
			prob=calculateProbability(data[n,:],mean[k,:],covariance[k,:,:])			
			den+=piK[k]*prob	
		den1[n]=den

	for n in range(data.shape[0]):
		den=0
		for k in range(K):
			prob=calculateProbability(data[n,:],mean[k,:],covariance[k,:,:])			
			responsibility[n,k]=(piK[k]*prob)/den1[n]

		#responsibility[n,:]=responsibility[n,:]/den
		#print("resp=",responsibility[n,:])
	return responsibility.astype('float64')

def validation(validationData,mean,covariance,K):
	features=runKMeans(data,K)
	for i in range(10):
		mean,covariance,likelihood=createGaussianMixture(data,features,K+i)
		maxLike=np.max(likelihood)
	index=np.argmax(maxLike)
	print("The best K value for the given Dataset =",K+index)

def test(testData,mean1,covariance1,mean2,covariance2,K1,K2,label,piK1,piK2):

	N=testData.shape[0]
	prob=np.zeros((N,2))
	count=0
	
	
	for n in range(N):
		for k in range(K1):
			prob[n,0]+=piK1[k]*calculateProbability(testData[n],mean1[k,:],covariance1[k,:,:])
		for k in range(K2):	
			prob[n,1]+=piK2[k]*calculateProbability(testData[n],mean2[k,:],covariance2[k,:,:])
		#print("max=",np.argmax(prob[n]))
	#print(np.sum(prob[:,0:K1],1))
	for n in range(N):

		if(np.argmax(prob[n])== label[n]-1):
			count=count+1
		#elif(np.argmax(prob[n])>=K1 and label[n]==2):
		#	count= count+1
	print("accuracy%=",count)
	np.save("E:\Arjun\work\programs\python\code\pr\\assignment3\plot\\prob.npy",prob)
	return count
def main():
	K1=K2=2
	for i in range(1):
		K1=K1+1
		K2=K2+1
		N=1
		K1=K2=16
		data1,validationData1,testData1=readDate("class1")
		
		
		features1,plt1=runKMeans(data1,K1)
		mean1,covariance1,likelihood1,piK1=createGaussianMixture(data1,features1,K1,N)
		title="contour"
		
		plt1=plotQ1.plotContours(mean1, covariance1, plt1, title, K1,K1,K2,N,figure = 1)
		data2,validationData2,testData2=readDate("class2")
		features2,plt2=runKMeans(data2,K2)
		#plt1.plot(plt2)
		mean2,covariance2,likelihood2,piK2=createGaussianMixture(data2,features2,K2,N)
		title="contour"
		
		plt2=plotQ1.plotContours(mean2, covariance2, plt1, title, K2,K1,K2,N,figure = 1)
		#plt2.show()
		m,n=testData1.shape
		print(testData1.shape)
		testData=np.vstack((testData1,testData2))
		print(testData.shape)

		label=np.zeros((2*m,1))
		label[0:m]=1
		label[m:2*m]=2
		print(label.shape)
		count=test(testData,mean1,covariance1,mean2,covariance2,K1,K2,label,piK1,piK2)
		text_file = open("E:\Arjun\work\programs\python\code\pr\\assignment3\plot\\accuracy.txt", "a")
		text_file.write("\n")
		text_file.write("K1= %s " % K2)
		text_file.write("K2= %s " % K1)
		text_file.write("N= %s " % N)
		text_file.write("accuracy: %s " % (count/400))
		text_file.close()
		plotQ1.boundaryRegion(data1,plt2,mean1,mean2,covariance1,covariance2,K1,K2,piK1,piK2,N)
	#plt2.show()
main()