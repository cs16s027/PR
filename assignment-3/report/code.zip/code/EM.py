from __future__ import division
import numpy as np
import math
from scipy.stats import multivariate_normal

def calculateProbability(data,mean,covariance):
	
	'''u=data-mean
	det=np.sqrt(np.linalg.det(covariance))
	sqrtpi2=2*np.pi	
	inv=np.linalg.inv(covariance)
	a=np.multiply(np.transpose(u),inv)	
	prob=np.exp(-0.5*np.sum(np.multiply(np.multiply(np.transpose(u),inv),u)))
	
	#print(det)	
	prob=prob/(sqrtpi2*det)'''
	var = multivariate_normal(mean=mean, cov=covariance)
	prob=var.pdf(data)
	return prob

def expectationStep(data,clusterData,mean,covariance,K,piK):
	Nk=np.zeros((K,1))
	
	responsibility=calculateResponsibility(data,mean,covariance,piK,K)
	#print("kmean=",mean)
	#print("kmencov=",covariance)
	for k in range(K):
		for n in range(data.shape[0]):
			
			Nk[k,0]=+responsibility[n,k]
	#print(Nk)
	Nk=np.sum(responsibility,0)
	print("sum",np.sum(responsibility,1))
	return responsibility,Nk


def maximizationStep(data,clusterData,mean,Nk,responsibility,K):
	newMean=np.zeros((K,2))

	newCovariance=np.zeros((K,2,2))	
	newPiK=np.zeros((K,1))
	diff=np.zeros((2,1))
	
	for k in range(K):
		N=0
		
		for n in range(data.shape[0]):
			newMean[k,:]=newMean[k,:]+responsibility[n,k]*data[n,:]			
			N+=responsibility[n,k]
			
		
		newMean[k,:]=newMean[k,:]/Nk[k]	
		
		for n in range(data.shape[0]):
			
			diff=data[n,:]-newMean[k,:]
			diff=np.transpose(np.asmatrix(diff))

			#print(diff.shape,np.transpose(diff).shape)
			newCovariance[k,:,:]+=responsibility[n,k]*(np.dot(diff,np.transpose(diff)))
			
		newCovariance[k,:,:]=newCovariance[k,:,:]/Nk[k]	

		#print("gmmcova=",newCovariance)
		newPiK[k]=N/data.shape[0]
		#print(np.sum(newPiK))
	#print("gmmmeans=",newMean)
	#print("cov=",newCovariance)	
	for i in range(K):
		for j in range(2):
			for k in range(2):
				if(j!=k):
					newCovariance[i,j,k]=0
	prob=evaluateLogLikelihood(data,newMean,newCovariance,newPiK,K)
	#print(prob)
	return newMean,newCovariance,newPiK,prob

def evaluateLogLikelihood(data,mean,covariance,piK,K):
	like=0
	#print("covariance=",covariance)
	#print("pik=",piK)
	#print("mean=",mean)
	for n in range(data.shape[0]):
		sum1=0
		for k in range(K):
			prob=calculateProbability(data[n,:],mean[k,:],covariance[k,:,:])
			#print("prob=",prob)
			sum1+=piK[k]*prob
		like+=math.log(sum1)	
	print("lik=",like)
	return like
def calculateResponsibility(data,mean,covariance,piK,K):
	responsibility=np.zeros((data.shape[0],K))
	den1=np.zeros(data.shape[0])

	for n in range(data.shape[0]):
		den=0
		for k in range(K):
			prob=calculateProbability(data[n,:],mean[k,:],covariance[k,:,:])			
			den+=piK[k]*prob	
		den1[n]=den

	for n in range(data.shape[0]):
		den=0
		for k in range(K):
			prob=calculateProbability(data[n,:],mean[k,:],covariance[k,:,:])			
			responsibility[n,k]=(piK[k]*prob)/den1[n]

		#responsibility[n,:]=responsibility[n,:]/den
		#print("resp=",responsibility[n,:])
	return responsibility.astype('float64')


def runUpdate(data,clusterData,mean,covariance,K,piK,N):
	
	likelihood=np.zeros(N)

	
	for i in range(N):

		responsibility,Nk=expectationStep(data,clusterData,mean,covariance,K,piK)
		newMean,newCovariance,newPiK,prob=maximizationStep(data,clusterData,mean,Nk,responsibility,K)
		mean=newMean
		covariance=newCovariance
		pik=newPiK
		#print("newmean=",mean)
		#print("newCovariance=",covariance)
		#print("pik=",piK)
		likelihood[i]=prob
	print("likehood=",likelihood)
	return newMean,newCovariance,likelihood