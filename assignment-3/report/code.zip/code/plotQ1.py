import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.cm as cm
from scipy.stats import multivariate_normal

def multivariateNormalPDF(xy, mean, cov):
    z = []
    det_cov = np.linalg.det(cov)
    factor = 1.0 / np.sqrt(np.power(2 * np.pi, 2) * np.linalg.det(cov))
    for x, y in xy:
        point = np.array([x, y])
        exponent = -0.5 * np.dot(np.dot((point - mean).T, np.linalg.inv(cov)), (point - mean))
        z.append(np.exp(exponent))
    z = np.array(z) * factor
    print(z.shape)
    return z

def calculateProbability(data,mean,covariance):
	var = multivariate_normal(mean=mean, cov=covariance)
	prob=var.pdf(data)
	return prob

def plotKMeans(data,features,k):
	labels=features.labels_
	for i in range(k):
		lab=label=[j for j,x in enumerate(labels) if x==i]
		datum=[data[j] for j in lab]
		datum=np.asarray(datum)
		print(datum.shape)
		plt.plot(datum[:,0],datum[:,1],'o')
		plt.xlabel('X_Coordinate')
		plt.ylabel('Y_Coordinate')
		plt.title('KMeans with K='+`k`)
	#plt.show()
	return plt

def plotContours(mus, covs, plot, title,K,K1,K2,N,figure = 1):
    print 'Plotting contours'
    #plot.clf()
    # Initialize the matplotlib figure object
    fig = plt.figure(figure)
    # A 3d axes object
    ax = fig.gca()

    # Compute the gaussian for each class
    xs, ys, zs = [], [], []
    for label in range(K):
        mu, cov = mus[label], covs[label]
        x, y = np.mgrid[mu[0] - 5 : mu[0] + 5 : 200j, mu[1] - 5: mu[1] + 5 : 200j]
        xy = np.column_stack([x.flat, y.flat])
        # Compute the gaussian on this grid with mean = mu, covariance = cov
        z = multivariateNormalPDF(xy, mu, cov)
        z = z.reshape(x.shape)
        # Populate Gaussians : zs
        xs.append(x)
        ys.append(y)
        zs.append(z)
    print(len(zs))
    # Plot the contours
    for label in range(K):
        # Contour plot 
        ax.contour(xs[label], ys[label], zs[label], cmap = cm.coolwarm)

        # Plot the directions
        mu, cov = mus[label], covs[label]
        _, eigvec = np.linalg.eig(cov)
        eig_extent = 1
        direction_1 = mu + eig_extent * eigvec[:, 0]
        direction_2 = mu + eig_extent * eigvec[:, 1]
        plt.plot([mu[0], direction_1[0]], [mu[1], direction_1[1]], color = 'black')
        plt.plot([mu[0], direction_2[0]], [mu[1], direction_2[1]], color = 'black')

    # Label the axes
    ax.set_xlabel('X axis')
    ax.set_ylabel('Y axis')

    # Name the classes
    '''ax.text(6, 0, 'Class-0')
    ax.text(-6, 9.0, 'Class-2')
    ax.text(13, 6.5, 'Class-1')
	'''
    # Save the figure
    plt.savefig("E:\Arjun\work\programs\python\code\pr\\assignment3\plot\\contorK1="+`K1`+"K2="+`K2`+"N="+`N`)
    plt.title(title)
    #plt.show()
    return plt

def boundaryRegion(data,plt,mean1,mean2,covariance1,covariance2,K1,K2,piK1,piK2,N):
 	h=0.25
 	x_min, x_max = data[:, 0].min() - 4, data[:, 0].max() + 6
	y_min, y_max = data[:, 1].min() - 4, data[:, 1].max() + 6
	xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
	                     np.arange(y_min, y_max, h))
	arg=np.c_[xx.ravel(), yy.ravel()]
	
	#print(Z)

	# Put the result into a color plot
	red1=green1=blue1=0;
	print("arg",arg.shape)
	Z=np.zeros((arg.shape[0]))
	for i in range(arg.shape[0]):
		pr1=pr2=0
		for k in range(K1):
			pr1 += piK1[k]*calculateProbability(arg[i],mean1[k,:],covariance1[k,:,:])
		for k in range(K2):
			pr2 += piK2[k]*calculateProbability(arg[i],mean2[k,:],covariance2[k,:,:])  
		if(pr1>=pr2):
			red1=red1+1
			Z[i]=0
		else:
			blue1=blue1+1;
			Z[i]=1
	
	red=np.zeros((red1,2))
	blue=np.zeros((blue1,2))
	print("count=",red1,blue1)
	for i in range(arg.shape[0]):
		if(Z[i]==0):
			red1=red1-1;
			red[red1,:]=arg[i,:]
		elif(Z[i]==1):
			blue1=blue1-1;
			blue[blue1,:]=arg[i,:]
	print("blue=",blue)
	#print(yy)1
	limit=data.shape[0];
	size=limit/3
	plt.plot(red[:,0],red[:,1],'go',label='class1')
	plt.plot(blue[:,0],blue[:,1],'yo',label='class2')
	plt.legend(loc='upper right')#['class1','class2','class3'],loc="upper right")
	'''plt.plot(data[0:size,0],data[0:size,1],'cx',label='class1');
	plt.plot(data[size:2*size,0],data[size:2*size,1],'wx',label='class2')
	plt.plot(data[2*size:limit,0],data[2*size:limit,1],'yx',label='class3')'''
	plt.legend(loc='upper right')
	plt.xlabel('X_cordinate')
	plt.ylabel('Y_cordinate')
	plt.title('Decision boundary and surface')
	print("printing")
	plt.savefig("E:\Arjun\work\programs\python\code\pr\\assignment3\plot\\boundaryK1="+`K1`+"K2="+`K2`+"N="+`N`)
	plt.show()





